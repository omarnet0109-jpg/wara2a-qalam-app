plugins {
    id("com.android.application")
}

android {
    namespace = "com.waraqawqalam.store"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.waraqawqalam.store"
        minSdk = 21
        targetSdk = 36
        versionCode = 2
        versionName = "1.0.1"
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
